<?php
$hostname = "mariadb";
$username = "root";
$password = "root";
$dbname = "scarf";
?>