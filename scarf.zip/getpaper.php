<?php  include_once("functions.php");
if (defined('PHP_VERSION_ID') && (PHP_VERSION_ID >= 50600)) {
	require_once "./mysql.php";
}
$id = (int) $_GET['paper_id'];

$result = query("SELECT title, pdf, pdfname FROM papers WHERE paper_id='$id'");

list($title, $pdf, $pdfname) = mysql_fetch_row($result);

$pdfname = $title . ".pdf";

header("Content-type: application/xpdf");
header("Content-Length: ". strlen($pdf));
header("Content-Disposition: attachement; filename=\"$pdfname\"");

print $pdf;

?>
