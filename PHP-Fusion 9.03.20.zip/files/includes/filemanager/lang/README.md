Other languages you can find here: https://github.com/trippo/ResponsiveFilemanager/tree/master/filemanager/lang
