Other languages you can find here: https://github.com/moment/moment/tree/develop/locale
