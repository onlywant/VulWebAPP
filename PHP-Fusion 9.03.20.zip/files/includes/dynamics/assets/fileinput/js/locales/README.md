Other languages you can find here: https://github.com/kartik-v/bootstrap-fileinput/tree/master/js/locales
