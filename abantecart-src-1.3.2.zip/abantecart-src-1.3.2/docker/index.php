<?php
echo 'hello <br>';
phpinfo();
?>