<?php

xdescribe('database\\record (TODO: Write tests)', function () {

});
