<?php

return [

    'panel'   => 'Administration Panel',
    'title'   => 'Welcome to your Anchor site',
    'message' => 'Here you will find all of the tools you will need to produce content for your website, manage users, posts and pages. For more information on what you can do with Anchor, please see our documentation at <a href="https://anchorcms.com/docs">http://anchorcms.com/docs</a>',

];
